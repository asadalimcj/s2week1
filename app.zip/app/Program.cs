﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace signIn
{
    class Program
    {
        static void Main(string[] args)
        {

            string[] city = { "sialkot", "islamabad", "rawalpindi", "faisalabad", "zafarwal" };
            string[] fare =  { "500", "200", "300", "400", "654" };
            string path = "D:\\uetlahore\\semester2\\OOP\\labs\\week1lab\\new.TXT";
            string path1 = "D:\\uetlahore\\semester2\\OOP\\labs\\week1lab\\app\\setFare.txt";
            string[] name = new string[5];
            string[] password = new string[5];
            int choice = 0;
            int x = 0;
            int Tseat = 60;
            int discount = 30;
            string description = "Travel and Enjoy with us";
            string contact = "03029614436";
            string email = "faisalmovers@gmail.com";
            while (choice != 3)
            {
                ReadFareFromFile(path1, city, fare, x);
                ReadFromFile(path, name, password);
                Console.Clear();
                choice = Menu();
                Console.Clear();
                if (choice == 1)
                {
                    Console.WriteLine("enter name:");
                    string n = Console.ReadLine();
                    Console.WriteLine("enter password:");
                    string pass = Console.ReadLine();
                    SignUp(path, n, pass);

                }
                else if (choice == 2)
                {
                    Console.WriteLine("enter name:");
                    string n = Console.ReadLine();
                    Console.WriteLine("enter passwod:");
                    string pas = Console.ReadLine();
                    bool lognin = signIn(n, pas, name, password, 5);
                    if (lognin == true)
                    {
                        Console.WriteLine("succefully");
                        Console.ReadKey();
                        Console.Clear();
                        TopHeader();
                        int num = AdminMenu();
                        if (num == 1)
                        {
                            Console.Clear();
                            TopHeader();
                            string Ncity;
                            Console.WriteLine("enter the name of city you want to change:");
                            Ncity = Console.ReadLine();
                            setfare(path1, Ncity, city, fare);
                            StoreFareInFile(path1, city,fare);
                            Console.WriteLine("enter a key");
                            for(int idx = 0; idx<5; idx++)
                            {
                                Console.WriteLine(fare[idx]);
                            }
                            Console.ReadKey();
                        }
                        if(num ==2)
                        {
                            Console.Clear();
                            TopHeader();
                            SeatRecord(Tseat);
                            Console.WriteLine("enter a key:");
                            Console.ReadKey();
                        }
                        if(num==3)
                        {
                            Console.Clear();
                            TopHeader();
                            Console.WriteLine("enter city name:");
                            string City = Console.ReadLine();
                            Console.WriteLine("enter number of seats:");
                            string seato = Console.ReadLine();
                            Console.WriteLine("enter the day:");
                            string day = Console.ReadLine();
                            int length = seato.ToString().Length;
                            int count = 0;
                            for(int idx = 0; idx<length; idx++)
                            {
                                int value = seato[idx] - '0';
                                if(value >=0 && value<10)
                                {
                                    count++;
                                }
                            }
                            if(count == length)
                            {
                                int result = BillPrep(City, seato, day, city, fare, discount);
                                Console.WriteLine("this can be your bill {0}", result);
                                Console.WriteLine("enter a key");
                                Console.ReadKey();
                            }
                            else
                            {
                                Console.WriteLine("invalid entity!");
                                Console.WriteLine("press a key:");
                                Console.ReadKey();
                            }
                        }
                        if(num ==4)
                        {
                            Console.Clear();
                            TopHeader();
                            AdminAboutUS(description, contact, email);
                            Console.WriteLine("enter a key:");
                            Console.ReadKey();
                        }

                    }
                    else
                    {
                        Console.WriteLine("not found");
                        Console.ReadKey();
                    }


                }
            }

        }
        static int Menu()
        {
            int number;
            Console.WriteLine("1: signUp");
            Console.WriteLine("2: lognIn");
            Console.WriteLine("3: Exit");
            Console.WriteLine("enter your choice:");
            number = int.Parse(Console.ReadLine());
            return number;
        }
        static bool signIn(string name, string pass, string[] UserName, string[] password, int count)
        {
            bool flag = false;
            for (int idx = 0; idx < count; idx++)
            {
                if (name == UserName[idx] && pass == password[idx])
                {
                    flag = true;
                }
            }
            return flag;
        }
        static void SignUp(string path, string name, string password)
        {
            StreamWriter file = new StreamWriter(path, true);
            file.WriteLine(name + "," + password);
            file.Flush();
            file.Close();
        }
        static string parseData(string record, int field)
        {
            int comma = 1;
            string item = "";
            for (int idx = 0; idx < record.Length; idx++)
            {
                if (record[idx] == ',')
                {
                    comma++;
                }
                else if (comma == field)
                {
                    item = item + record[idx];
                }
            }
            return item;
        }
        static void ReadFromFile(string path, string[] name, string[] password)
        {
            int x = 0;
            if (File.Exists(path))
            {
                StreamReader fileVar = new StreamReader(path);
                string record;
                while ((record = fileVar.ReadLine()) != null)
                {
                    name[x] = parseData(record, 1);
                    password[x] = parseData(record, 2);
                    x++;
                    if (x > 5)
                    {
                        break;
                    }
                }
                fileVar.Close();
            }
            else
            {
                Console.WriteLine("not available");
            }
        }
        static void TopHeader()
        {
            Console.WriteLine("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
            Console.WriteLine(".....................................................");
            Console.WriteLine(".....................................................");
            Console.WriteLine(" ................FAISAL MOVERS.......................");
            Console.WriteLine(".....................................................");
            Console.WriteLine(".....................................................");
            Console.WriteLine("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
        }
        static int userMenue()
        {
            Console.Clear();
            TopHeader();
            int choice;
            Console.WriteLine("         USER MENUE");
            Console.WriteLine("1.CHECK FARES");
            Console.WriteLine("2.DESTINATIONS");
            Console.WriteLine("3.BOOK SEAT");
            Console.WriteLine("4.COMPANY INFO");
            Console.WriteLine("5.FEEDBACK/SUGGESTION");
            Console.WriteLine("6.PAY BILL");
            Console.WriteLine("7.MY SEAT INFO");
            Console.WriteLine("8. EXIT");
            Console.WriteLine("ENTER YOUR CHOICE");
            choice = int.Parse(Console.ReadLine());
            return choice;
        }
        static int AdminMenu()
        {
            Console.Clear();
            TopHeader();
            Console.WriteLine("............ADMIN MENU..........");
            Console.WriteLine("1.SET FARES");
            Console.WriteLine("2.SEAT RECORD");
            Console.WriteLine("3. BILLS / DISCOUNT");
            Console.WriteLine("4. ABOUT US");
            Console.WriteLine("5.VIEW FEEDBACK");
            Console.WriteLine("6.VIEW USER STATUS");
            Console.WriteLine("7.EXIT");
            Console.WriteLine("ENTER YOUR CHOICE");
            int choice = int.Parse(Console.ReadLine());
            return choice;
        }
        static void setfare(string path, string city, string[] cityName, string[] fare)
        {
            int len = 0; ;
            int count = 0;
            int count1 = 0;
            int index = 0;
            string price ="";
            for (int idx = 0; idx < 5; idx++)
            {
                if (city == cityName[idx])
                {
                    index = idx;
                    count++;
                }
            }
            if (count == 1)
            {
                Console.WriteLine("enter new price:");
                price =Console.ReadLine();
                len = price.ToString().Length;
                for(int idx = 0; idx<len; idx++)
                {
                    int value = price[idx] - '0';
                    if (value >= 0 && value < 10);
                    {
                        count1++;
                    }
                }
            }
            if (count == 0)
            {
                Console.WriteLine("invalid location");
                Console.ReadKey();
            }
            if(count1==len)
            {
                StoreFareInFile(path, cityName, fare);
                fare[index] = price;
                Console.WriteLine("updated");
                Console.ReadKey();
            }
            if(count1==0)
            {
                Console.WriteLine("invalid entity");
                Console.ReadKey();
            }
            
        }
        static void SeatRecord(int Tseat)
        {
            if(Tseat>0)
            {
                Console.WriteLine("the remaining seat are {0}", Tseat);
                Console.ReadKey();
            }
            else if (Tseat<=0)
            {
                Console.WriteLine("all seats are occupied:");
                Console.ReadKey();
            }
        }
        static int BillPrep(string City, string seat, string day, string[] city, string[] fare, int discount)
        {
            int bill;
            int seatNum = int.Parse(seat);
            if ((day == "sunday" || day == "Sunday") || (day == "saturday" || day == "Saturday"))
            {
                for(int idx = 0; idx<5; idx++)
                {
                    if(City == city[idx])
                    {
                        string temp = fare[idx];
                        int setPrice = int.Parse(temp);
                        bill = ((seatNum * setPrice) - (discount * seatNum * setPrice) / 100);
                        return bill;
                    }
                }
            }
            else if ((day == "monday" || day == "Monday") || (day == "tuesday" || day == "Tuesday") || (day == "wednesday" || day == "Wednesday") || (day == "thursday" || day == "Thursday") || (day == "friday" || day == "Friday"))
            {
                for(int idx = 0; idx<5; idx++)
                {
                    if(City== city[idx])
                    {
                        string temp = fare[idx];
                        int setPrice = int.Parse(temp);
                        bill = seatNum * setPrice;
                        return bill;
                    }
                }
            }
            else
            {
                Console.WriteLine("invalid day:");
                Console.WriteLine("enter a key:");
                Console.ReadKey();
            }
            return bill = 0;
        }
        static void UserAboutUs(string description, string contact, string email)
        {
            Console.WriteLine("ABOUT US");
            Console.WriteLine(description);
            Console.WriteLine("CONTACT US AT: {0}", contact);
            Console.WriteLine("Email US :{0}", email);
        }
        static void AdminAboutUS(string description, string contact, string email)
        {
            string confirmation;
            Console.WriteLine("ABOUT US:     {0}", description);
            Console.WriteLine("CONTACT US AT: {0}", contact);
            Console.WriteLine("EMAIL US AT : {0}", email);
            Console.WriteLine("do you wnat to change ABOUT US? (Y/N)");
            confirmation = Console.ReadLine();
            if (confirmation == "y" || confirmation == "y")
            {
                string E_mail;
                string Contact1;
                int length;
                Console.WriteLine("ABOUT US:");
                description = Console.ReadLine();
                Console.WriteLine("CONTACT US AT:");
                Contact1 = Console.ReadLine();
                length = Contact1.Length;
                int count = 0;
                if(length==11)
                {
                    for(int idx = 0; idx<11; idx++)
                    {
                        int value = Contact1[idx] - '0';
                        if(value>=0 && value<10)
                        {
                            count++;
                        }
                    }
                    if(count == 11)
                    {
                        contact = Contact1;
                        Console.WriteLine("contact has been changed successfully:");
                        Console.WriteLine("enter a key:");
                        Console.ReadKey();
                    }
                    else
                    {
                        Console.WriteLine("invalid phone number entered:");
                        Console.WriteLine("press a key:");
                        Console.ReadKey();
                    }
                }
                else
                {
                    Console.WriteLine("invalid phone number entered:");
                    Console.WriteLine("press a key:");
                    Console.ReadKey();
                }
                Console.WriteLine("enter email:");
                E_mail = Console.ReadLine();
                length = E_mail.Length;
                int Count = 0;
                for(int idx = 0; idx<length; idx++)
                {
                    if (E_mail[idx]== '@')
                    {
                        Count++;
                    }
                }
                if(Count == 1)
                {
                    email = E_mail;
                }
                else
                {
                    Console.WriteLine("invalid email entered");
                    Console.WriteLine("press a key:");
                    Console.ReadKey();
                }
            }
            UserAboutUs(description, contact, email);
        }
        static void StoreFareInFile(string path, string[] city, string[] fare)
        {
            StreamWriter file = new StreamWriter(path, false);
            for(int idx = 0; idx<5; idx++)
            {
                file.WriteLine(city[idx] + "," + fare[idx]);
            }
            file.Flush();
            file.Close();
        }
        static void ReadFareFromFile(string path, string[] city, string[] fare, int x)
        {
            if(File.Exists(path))
            {
                StreamReader setfare = new StreamReader(path);
                string record;
                while ((record = setfare.ReadLine()) != null)
                {
                    if (x > 5)
                    {
                        break;
                    }
                    city[x] = parseData(record, 1);
                    fare[x] = parseData(record, 2);
                    x++;
                }
                setfare.Close();
            }
            else
            {
                Console.WriteLine("not available");
            }
        }

    }

}

