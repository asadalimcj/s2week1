﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using EZInput;

namespace game
{
    class Program
    {
        static void Main(string[] args)
        {
            char[,] maze = new char[33, 106];
            //string[,] maze = {
                //{ "#######################################################################################################"},
                //{ "##                                                                                                    ##"},
                //{ "##                                                                                                    ##"},
                //{ "##                                                                                                    ##"},
                //{ "##                                 #####################################                              ##"},
                //{ "##        ##########################                                  %%%%%%%%%%%%%%%%%%%%%%%%        ##"},
                //{ "##                                                                                                    ##"},
                //{ "##                                                                                                    ##"},
                //{ "##                                                                                                    ##"},
                //{ "##%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%                   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%##"},
                //{ "##                                                                                                    ##"},
                //{ "##                                                                                                    ##"},
                //{ "##                       %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%                     ##"},
                //{ "##                                                                                                    ##"},
                //{ "##                                                                                                    ##"},
                //{ "##       %%%%%%%%%%%%%%%%%%%                   %%%%%%%%%%%%%%%%%%%%%%         %%%%%%%%%%%%%%%%%%%%%%%%##"},
                //{ "##                                                %%                                                  ##"},
                //{ "##                                                %%                                                  ##"},
                //{ "##                       %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%                  ##"},
                //{ "##                                                %%                                                  ##"},
                //{ "##       %%                                       %%                                        %%        ##"},
                //{ "##       %%      %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    %%        ##"},
                //{ "##       %%                                       %%                                        %%        ##"},
                //{ "##       %%                                       %%                                        %%        ##"},
                //{ "##       %%         %%%%%%%%                %%%%%%%%%%%%%%%%%%%%%           %%%%%%%%        %%        ##"},
                //{ "##                                                %%                                                  ##"},
                //{ "##                                                %%                                                  ##"},
                //{ "##       %%                                       %%                                        %%        ##"},
                //{ "##       %%                                       %%                                        %%        ##"},
                //{ "##                                                                                                    ##"},
                //{ "##                                                                                                    ##"},
                //{ "##%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%##"},
                //{ "########################################################################################################"}};
            string[,] logo = {

                { " @@@@@@   @@@  @@@   @@@@@@   @@@  @@@  @@@     @@@@@@@   @@@@@@@    @@@@@@   "},
                { "@@@@@@@   @@@@ @@@  @@@@@@@@  @@@  @@@  @@@     @@@@@@@@  @@@@@@@@  @@@@@@@@  "},
                { "!@@       @@!@!@@@  @@!  @@@  @@!  @@!  @@!     @@!  @@@  @@!  @@@  @@!  @@@  "},
                { "!@!       !@!!@!@!  !@!  @!@  !@!  !@!  !@!     !@   @!@  !@!  @!@  !@!  @!@  "},
                { "!!@@!!    @!@ !!@!  @!@  !@!  @!!  !!@  @!@     @!@!@!@   @!@!!@!   @!@  !@!  "},
                { " !!@!!!   !@!  !!!  !@!  !!!  !@!  !!!  !@!     !!!@!!!!  !!@!@!    !@!  !!!  "},
                { "     !:!  !!:  !!!  !!:  !!!  !!:  !!:  !!:     !!:  !!!  !!: :!!   !!:  !!!  "},
                { "    !:!   :!:  !:!  :!:  !:!  :!:  :!:  :!:     :!:  !:!  :!:  !:!  :!:  !:!  "},
                { ":::: ::    ::   ::  ::::: ::   :::: :: :::       :: ::::  ::   :::  ::::: ::  "},
                { ":: : :    ::    :    : :  :     :: :  : :       :: : ::    :   : :   : :  :   "}};
            string[,] play1 = { 
                {"(@@)->"},
                {" W    "} };
            string[,] lynch = { 
                {"<+(UU)"},
                {"   H  "} };
            PrintLogi(logo);
            Console.WriteLine("press a key to conyinue:");
            Console.ReadKey();
            int choice = 0;
            int PlayerHealth = 100;
            int lynchHealth = 100;
            int score = 0;
            int SnowbroX = 2;
            int SnowbroY = 3;
            int LynchX = 92;
            int LynchY = 6;
            while (choice != 3)
            {
                Console.Clear();
                choice = MainMenu();
                if(choice == 1)
                {
                    if(PlayerHealth>0)
                    {
                        Console.Clear();
                        ReadMaze(maze);
                        PrintMaze(maze);
                        PrintSnowBro(play1, ref SnowbroX, ref SnowbroY);
                        PrintLynch(lynch, LynchX, LynchY);
                        while(true)
                        {
                            PrintScore(score, PlayerHealth, lynchHealth);
                            if (Keyboard.IsKeyPressed(Key.UpArrow))
                            {
                                moveUp(maze, ref SnowbroX, ref SnowbroY, play1, ref SnowbroX, ref SnowbroY);

                            }  
                            if(Keyboard.IsKeyPressed(Key.DownArrow))
                            {
                                MoveDown(maze, ref SnowbroX, ref SnowbroY, play1, ref SnowbroX, ref SnowbroY);
                            }
                            if(Keyboard.IsKeyPressed(Key.LeftArrow))
                            {
                                moveLeft(maze, ref SnowbroX, ref SnowbroY, play1, ref SnowbroX, ref SnowbroY);
                            }
                            if(Keyboard.IsKeyPressed(Key.RightArrow))
                            {
                                moveRight(maze, ref SnowbroX, ref SnowbroY, play1, ref SnowbroX, ref SnowbroY);
                            }
                                Console.ReadKey();
                        }
                    }
                }
            }

        }
        static void PrintMaze(char[,] maze)
        {
            for (int row = 0; row < 33; row++)
            {
                for (int col = 0; col < 106; col++)
                {
                    Console.Write( maze[row,col]);
                }
                Console.WriteLine();
            }
        }
        static void PrintLogi(string[,] logo)
        {
            for (int row = 0; row < 10; row++)
            {
                for (int col = 0; col < 1; col++)
                {
                    Console.WriteLine(logo[row,col]);
                }
            }
        }
        static int MainMenu()
        {
            Console.WriteLine("1. \tSTART");
            Console.WriteLine("2.'\tOPTION");
            Console.WriteLine("3. \tEXIT");
            Console.WriteLine("---------------------------");
            Console.WriteLine("ENTER A CHOICE:");
            int option = int.Parse(Console.ReadLine());
            return option;
        }
        static void PrintSnowBro(string[,] play1,ref int x, ref int y)
        {
           gotoxy(x, y);
            for (int row = 0; row < 2; row++)
            {
                for (int col = 0; col <1; col++)
                {
                    Console.WriteLine(play1[row,col]);
                }
                gotoxy(x, y + 1);
            }
        }
        static void gotoxy(int x, int y)
        {
            Console.SetCursorPosition(x, y);
        }
        static void PrintLynch(string[,] lynch, int x, int y)
        {
            gotoxy(x, y);
            for (int row = 0; row < 2; row++)
            {
                for (int col = 0; col < 1; col++)
                {
                    Console.WriteLine(lynch[row, col]);
                }
                gotoxy(x, y + 1);
            }
        }
        static void EraseLynch(int x, int y)
        {
            gotoxy(x, y);
            for (int idx = 0; idx < 1; idx++)
            {
                Console.Write(" ");
            }
            gotoxy(x, y + 1);
            for (int idx = 0; idx < 1; idx++)
            {
                Console.Write(" ");
            }
        }
        static void PrintScore(int score, int PlayerHealth, int LynchHealth)
        {
            gotoxy(120, 8);
            Console.WriteLine("SCORE: {0}", score);
            gotoxy(120, 9);
            Console.WriteLine("PLAYER HEALTH: {0} ", PlayerHealth);
            gotoxy(120, 10);
            Console.WriteLine("LYNCH HEALTH: {0}", LynchHealth);
        }
        static void moveUp(char[,] maze, ref int SnowbroX, ref int SnowbroY, string[,] play1, ref int x, ref int y)
        {
            if(maze[SnowbroX-1, SnowbroY] == ' ')
            {
                maze[SnowbroY, SnowbroX] = ' ';
                Console.SetCursorPosition(SnowbroY, SnowbroX);
                eraseSnowbro(ref SnowbroX,ref SnowbroY);
                SnowbroY = SnowbroY - 1;
                Console.SetCursorPosition(SnowbroY, SnowbroX);
                PrintSnowBro(play1, ref x, ref y);
            }
        }
        static void ReadMaze(char[,] maze)
        {
            StreamReader fp = new StreamReader("D:\\uetlahore\\semester2\\OOP\\labs\\week1lab\\game\\maze.txt");
            string record;
            int row = 0;
            while ((record = fp.ReadLine()) != null)
            {
                for (int x = 0; x < 104; x++)
                {
                    maze[row, x] = record[x];
                }
                row++;
            }

            fp.Close();
        }
       static void eraseSnowbro(ref int snowbroX, ref int snowbroY)
        {
            gotoxy(snowbroX, snowbroY);
            for (int idx = 0; idx < 6; idx++)
            {
                Console.Write(" ");
            }
            gotoxy(snowbroX, snowbroY + 1);
            for (int idx = 0; idx < 6; idx++)
            {
                Console.Write(" ");
            }
        }
        static void MoveDown(char[,] maze, ref int SnowbroX, ref int SnowbroY, string[,] play1, ref int x, ref int y)
        {
            if (maze[SnowbroX + 1, SnowbroY] == ' ')
            {
                Console.SetCursorPosition(SnowbroY, SnowbroX);
                eraseSnowbro(ref SnowbroX, ref SnowbroY);
                SnowbroY = SnowbroY + 1;
                Console.SetCursorPosition(SnowbroY, SnowbroX);
                PrintSnowBro(play1, ref x, ref y);
            }
        }
        static void moveLeft(char[,] maze, ref int SnowbroX, ref int SnowbroY, string[,] play1, ref int x, ref int y)
        {
            if (maze[SnowbroX - 1, SnowbroY] == ' ')
            {
                maze[SnowbroY, SnowbroX] = ' ';
                Console.SetCursorPosition(SnowbroY, SnowbroX);
                eraseSnowbro(ref SnowbroX, ref SnowbroY);
                SnowbroX = SnowbroX - 1;
                Console.SetCursorPosition(SnowbroY, SnowbroX);
                PrintSnowBro(play1, ref x, ref y);
            }
        }
        static void moveRight(char[,] maze, ref int SnowbroX, ref int SnowbroY, string[,] play1, ref int x, ref int y)
        {
            if (maze[SnowbroX + 1, SnowbroY] == ' ')
            {
                maze[SnowbroY, SnowbroX] = ' ';
                Console.SetCursorPosition(SnowbroY, SnowbroX);
                eraseSnowbro(ref SnowbroX, ref SnowbroY);
                SnowbroX = SnowbroX + 1;
                Console.SetCursorPosition(SnowbroY, SnowbroX);
                PrintSnowBro(play1, ref x, ref y);
            }
        }

    }
}
